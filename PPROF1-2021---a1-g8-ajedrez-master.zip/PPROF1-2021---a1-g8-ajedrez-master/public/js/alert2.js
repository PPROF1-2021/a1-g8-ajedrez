function alerta(){
    alert("esta es una alerta");
}